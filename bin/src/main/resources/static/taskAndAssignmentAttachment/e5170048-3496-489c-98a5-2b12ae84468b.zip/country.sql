-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2023 at 07:39 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spyssdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_id` bigint(20) NOT NULL,
  `capital` varchar(255) DEFAULT '',
  `country_name` varchar(150) DEFAULT '',
  `currency_code` varchar(255) DEFAULT '',
  `currency_name` varchar(255) DEFAULT '',
  `currency_symbole` varchar(100) DEFAULT '$',
  `emergency_number` varchar(255) DEFAULT NULL,
  `flag` varchar(255) DEFAULT 'KMs',
  `phone_code` varchar(255) DEFAULT '',
  `sort_name` varchar(255) DEFAULT '',
  `status` varchar(255) DEFAULT 'Deactive',
  `tax` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_id`, `capital`, `country_name`, `currency_code`, `currency_name`, `currency_symbole`, `emergency_number`, `flag`, `phone_code`, `sort_name`, `status`, `tax`, `unit`, `uuid`) VALUES
(1, 'Kabul', 'Afghanistan', 'AFN', 'Afghani', '$', '', 'afghanistan.gif', '+93', 'AF', 'Active', '', 'KMs', 'd4287c01-0bf7-11ed-9481-000c291151eb'),
(2, 'Tirana', 'Albania', 'ALL', 'Lek', '$', '', 'albania.gif', '+355', 'AL', 'Active', '', 'KMs', 'd4287dd5-0bf7-11ed-9481-000c291151eb'),
(3, 'Algiers', 'Algeria', 'DZD', 'Dinar', '$', '', 'algeria.gif', '+213', 'DZ', 'Active', '', 'KMs', 'd4287e28-0bf7-11ed-9481-000c291151eb'),
(4, '', 'American Samoa', '', '', '$', '', 'american_samoa.gif', '+', 'AS', 'Active', '', 'KMs', 'd4287e65-0bf7-11ed-9481-000c291151eb'),
(5, 'Andorra la Vella', 'Andorra', 'EUR', 'Euro', '$', '', 'andorra.gif', '+376', 'AD', 'Active', '', 'KMs', 'd4287e9e-0bf7-11ed-9481-000c291151eb'),
(6, 'Luanda', 'Angola', 'AOA', 'Kwanza', '$', '', 'angola.gif', '+244', 'AO', 'Active', '', 'KMs', 'd4287ed7-0bf7-11ed-9481-000c291151eb'),
(7, 'The Valley', 'Anguilla', 'XCD', 'Dollar', '$', '', 'anguilla.gif', '-263', 'AI', 'Active', '', 'KMs', 'd4287f0b-0bf7-11ed-9481-000c291151eb'),
(8, '', 'Antarctica', '', '', '$', '', '', '+', 'AQ', 'Active', '', 'KMs', 'd4287f41-0bf7-11ed-9481-000c291151eb'),
(9, 'Saint Johns', 'Antigua And Barbuda', 'XCD', 'Dollar', '$', '', '', '-267', 'AG', 'Active', '', 'KMs', 'd4287f7a-0bf7-11ed-9481-000c291151eb'),
(10, 'Buenos Aires', 'Argentina', 'ARS', 'Peso', '$', '', 'argentina.gif', '+54', 'AR', 'Active', '', 'KMs', 'd4287faf-0bf7-11ed-9481-000c291151eb'),
(11, 'Yerevan', 'Armenia', 'AMD', 'Dram', '$', '', 'armenia.gif', '+374', 'AM', 'Active', '', 'KMs', 'd428823d-0bf7-11ed-9481-000c291151eb'),
(12, 'Oranjestad', 'Aruba', 'AWG', 'Guilder', '$', '', 'aruba.gif', '+297', 'AW', 'Active', '', 'KMs', 'd428827e-0bf7-11ed-9481-000c291151eb'),
(13, 'Canberra', 'Australia', 'AUD', 'Dollar', '$', '', 'australia.gif', '+61', 'AU', 'Active', '', 'KMs', 'd42882b2-0bf7-11ed-9481-000c291151eb'),
(14, 'Vienna', 'Austria', 'EUR', 'Euro', '$', '', 'austria.gif', '+43', 'AT', 'Active', '', 'KMs', 'd42882e5-0bf7-11ed-9481-000c291151eb'),
(15, 'Baku', 'Azerbaijan', 'AZN', 'Manat', '$', '', 'azerbaijan.gif', '+994', 'AZ', 'Active', '', 'KMs', 'd4288317-0bf7-11ed-9481-000c291151eb'),
(16, '', 'Bahamas The', '', '', '$', '', '', '+', 'BS', 'Active', '', 'KMs', 'd4288348-0bf7-11ed-9481-000c291151eb'),
(17, 'Manama', 'Bahrain', 'BHD', 'Dinar', '$', '', 'bahrain.gif', '+973', 'BH', 'Active', '', 'KMs', 'd428837d-0bf7-11ed-9481-000c291151eb'),
(18, 'Dhaka', 'Bangladesh', 'BDT', 'Taka', '$', '', 'bangladesh.gif', '+880', 'BD', 'Active', '', 'KMs', 'd4288509-0bf7-11ed-9481-000c291151eb'),
(19, 'Bridgetown', 'Barbados', 'BBD', 'Dollar', '$', '', 'barbados.gif', '-245', 'BB', 'Active', '', 'KMs', 'd428853f-0bf7-11ed-9481-000c291151eb'),
(20, 'Minsk', 'Belarus', 'BYR', 'Ruble', '$', '', 'belarus.gif', '+375', 'BY', 'Active', '', 'KMs', 'd4288617-0bf7-11ed-9481-000c291151eb'),
(21, 'Brussels', 'Belgium', 'EUR', 'Euro', '$', '', 'belgium.gif', '+32', 'BE', 'Deactive', '', 'KMs', 'd428866f-0bf7-11ed-9481-000c291151eb'),
(22, 'Belmopan', 'Belize', 'BZD', 'Dollar', '$', '', 'belize.gif', '+501', 'BZ', 'Deactive', '', 'KMs', 'd4288831-0bf7-11ed-9481-000c291151eb'),
(23, 'Porto-Novo', 'Benin', 'XOF', 'Franc', '$', '', 'benin.gif', '+229', 'BJ', 'Deactive', '', 'KMs', 'd4288880-0bf7-11ed-9481-000c291151eb'),
(24, 'Hamilton', 'Bermuda', 'BMD', 'Dollar', '$', '', 'bermuda.gif', '-440', 'BM', 'Deactive', '', 'KMs', 'd42888cb-0bf7-11ed-9481-000c291151eb'),
(25, 'Thimphu', 'Bhutan', 'BTN', 'Ngultrum', '$', '', 'bhutan.gif', '+975', 'BT', 'Deactive', '', 'KMs', 'd4288a88-0bf7-11ed-9481-000c291151eb'),
(26, 'La Paz (administrative/legislative) and Sucre (judical)', 'Bolivia', 'BOB', 'Boliviano', '$', '', 'bolivia.gif', '+591', 'BO', 'Deactive', '', 'KMs', 'd4288ad9-0bf7-11ed-9481-000c291151eb'),
(27, 'Sarajevo', 'Bosnia and Herzegovina', 'BAM', 'Marka', '$', '', 'bosnia_and_herzegovina.gif', '+387', 'BA', 'Deactive', '', 'KMs', 'd4288c9c-0bf7-11ed-9481-000c291151eb'),
(28, 'Gaborone', 'Botswana', 'BWP', 'Pula', '$', '', 'botswana.gif', '+267', 'BW', 'Deactive', '', 'KMs', 'd4288e65-0bf7-11ed-9481-000c291151eb'),
(29, '', 'Bouvet Island', '', '', '$', '', '', '+', 'BV', 'Deactive', '', 'KMs', 'd4289009-0bf7-11ed-9481-000c291151eb'),
(30, 'Brasilia', 'Brazil', 'BRL', 'Real', '$', '', 'brazil.gif', '+55', 'BR', 'Deactive', '', 'KMs', 'd42891ae-0bf7-11ed-9481-000c291151eb'),
(31, '', 'British Indian Ocean Territory', '', '', '$', '', '', '+246', 'IO', 'Deactive', '', 'KMs', 'd42895c2-0bf7-11ed-9481-000c291151eb'),
(32, 'Bandar Seri Begawan', 'Brunei', 'BND', 'Dollar', '$', '', 'brunei.gif', '+673', 'BN', 'Deactive', '', 'KMs', 'd4289606-0bf7-11ed-9481-000c291151eb'),
(33, 'Sofia', 'Bulgaria', 'BGN', 'Lev', '$', '', 'bulgaria.gif', '+359', 'BG', 'Deactive', '', 'KMs', 'd428963d-0bf7-11ed-9481-000c291151eb'),
(34, 'Ouagadougou', 'Burkina Faso', 'XOF', 'Franc', '$', '', 'burkina faso.gif', '+226', 'BF', 'Deactive', '', 'KMs', 'd428966f-0bf7-11ed-9481-000c291151eb'),
(35, 'Bujumbura', 'Burundi', 'BIF', 'Franc', '$', '', 'burundi.gif', '+257', 'BI', 'Deactive', '', 'KMs', 'd42896a2-0bf7-11ed-9481-000c291151eb'),
(36, 'Phnom Penh', 'Cambodia', 'KHR', 'Riels', '$', '', 'cambodia.gif', '+855', 'KH', 'Deactive', '', 'KMs', 'd42896d4-0bf7-11ed-9481-000c291151eb'),
(37, 'Yaounde', 'Cameroon', 'XAF', 'Franc', '$', '', 'cameroon.gif', '+237', 'CM', 'Deactive', '', 'KMs', 'd4289706-0bf7-11ed-9481-000c291151eb'),
(38, 'Ottawa', 'Canada', 'CAD', 'Dollar', '$', '', 'canada.gif', '+1', 'CA', 'Deactive', '', 'KMs', 'd4289738-0bf7-11ed-9481-000c291151eb'),
(39, 'Praia', 'Cape Verde', 'CVE', 'Escudo', '$', '', 'cape verde.gif', '+238', 'CV', 'Deactive', '', 'KMs', 'd4289792-0bf7-11ed-9481-000c291151eb'),
(40, 'George Town', 'Cayman Islands', 'KYD', 'Dollar', '$', '', 'cayman islands.gif', '-344', 'KY', 'Deactive', '', 'KMs', 'd42897c5-0bf7-11ed-9481-000c291151eb'),
(41, 'Bangui', 'Central African Republic', 'XAF', 'Franc', '$', '', 'central_african_regif', '+236', 'CF', 'Deactive', '', 'KMs', 'd42897f9-0bf7-11ed-9481-000c291151eb'),
(42, 'N Djamena', 'Chad', 'XAF', 'Franc', '$', '', 'chad.gif', '+235', 'TD', 'Deactive', '', 'KMs', 'd428982e-0bf7-11ed-9481-000c291151eb'),
(43, 'Santiago (administrative/judical) and Valparaiso (legislative)', 'Chile', 'CLP', 'Peso', '$', '', 'chile.gif', '+56', 'CL', 'Deactive', '', 'KMs', 'd4289860-0bf7-11ed-9481-000c291151eb'),
(44, '', 'China', '', '', '$', '', 'china.gif', '+', 'CN', 'Deactive', '', 'KMs', 'd42898b9-0bf7-11ed-9481-000c291151eb'),
(45, 'The Settlement (Flying Fish Cove)', 'Christmas Island', 'AUD', 'Dollar', '$', '', '', '+61', 'CX', 'Deactive', '', 'KMs', 'd42898f0-0bf7-11ed-9481-000c291151eb'),
(46, 'West Island', 'Cocos (Keeling) Islands', 'AUD', 'Dollar', '$', '', '', '+61', 'CC', 'Deactive', '', 'KMs', 'd4289922-0bf7-11ed-9481-000c291151eb'),
(47, 'Bogota', 'Colombia', 'COP', 'Peso', '$', '', 'colombia.gif', '+57', 'CO', 'Deactive', '', 'KMs', 'd4289954-0bf7-11ed-9481-000c291151eb'),
(48, 'Moroni', 'Comoros', 'KMF', 'Franc', '$', '', '', '+269', 'KM', 'Deactive', '', 'KMs', 'd4289986-0bf7-11ed-9481-000c291151eb'),
(49, '', 'Congo', '', '', '$', '', 'congo.gif', '+', 'CG', 'Deactive', '', 'KMs', 'd42899ba-0bf7-11ed-9481-000c291151eb'),
(50, '', 'Congo The Democratic Republic Of The', '', '', '$', '', '', '+', 'CD', 'Deactive', '', 'KMs', 'd42899eb-0bf7-11ed-9481-000c291151eb'),
(51, 'Avarua', 'Cook Islands', 'NZD', 'Dollar', '$', '', 'cook_islands.gif', '+682', 'CK', 'Deactive', '', 'KMs', 'd4289a1d-0bf7-11ed-9481-000c291151eb'),
(52, 'San Jose', 'Costa Rica', 'CRC', 'Colon', '$', '', 'costa_rica.gif', '+506', 'CR', 'Deactive', '', 'KMs', 'd4289a4f-0bf7-11ed-9481-000c291151eb'),
(53, 'Yamoussoukro', 'Cote D Ivoire (Ivory Coast)', 'XOF', 'Franc', '$', '', '', '+225', 'CI', 'Deactive', '', 'KMs', 'd4289a82-0bf7-11ed-9481-000c291151eb'),
(54, '', 'Croatia (Hrvatska)', '', '', '$', '', 'croatia.gif', '+', 'HR', 'Deactive', '', 'KMs', 'd4289ab3-0bf7-11ed-9481-000c291151eb'),
(55, 'Havana', 'Cuba', 'CUP', 'Peso', '$', '', 'cuba.gif', '+53', 'CU', 'Deactive', '', 'KMs', 'd4289ae5-0bf7-11ed-9481-000c291151eb'),
(56, 'Nicosia', 'Cyprus', 'CYP', 'Pound', '$', '', 'cyprus.gif', '+357', 'CY', 'Deactive', '', 'KMs', 'd4289b17-0bf7-11ed-9481-000c291151eb'),
(57, 'Prague', 'Czech Republic', 'CZK', 'Koruna', '$', '', 'czech_regif', '+420', 'CZ', 'Deactive', '', 'KMs', 'd4289b47-0bf7-11ed-9481-000c291151eb'),
(58, 'Copenhagen', 'Denmark', 'DKK', 'Krone', '$', '', 'denmark.gif', '+45', 'DK', 'Deactive', '', 'KMs', 'd4289b79-0bf7-11ed-9481-000c291151eb'),
(59, 'Djibouti', 'Djibouti', 'DJF', 'Franc', '$', '', 'djibouti.gif', '+253', 'DJ', 'Deactive', '', 'KMs', 'd4289baa-0bf7-11ed-9481-000c291151eb'),
(60, 'Roseau', 'Dominica', 'XCD', 'Dollar', '$', '', '', '-766', 'DM', 'Deactive', '', 'KMs', 'd4289bdb-0bf7-11ed-9481-000c291151eb'),
(61, 'Santo Domingo', 'Dominican Republic', 'DOP', 'Peso', '$', '', 'dominican_regif', '+1-809 and 1-829', 'DO', 'Deactive', '', 'KMs', 'd4289c0c-0bf7-11ed-9481-000c291151eb'),
(62, '', 'East Timor', '', '', '$', '', '', '+', 'TP', 'Deactive', '', 'KMs', 'd4289c3e-0bf7-11ed-9481-000c291151eb'),
(63, 'Quito', 'Ecuador', 'USD', 'Dollar', '$', '', 'ecuador.gif', '+593', 'EC', 'Deactive', '', 'KMs', 'd4289c70-0bf7-11ed-9481-000c291151eb'),
(64, 'Cairo', 'Egypt', 'EGP', 'Pound', '$', '', 'egypt.gif', '+20', 'EG', 'Deactive', '', 'KMs', 'd4289ca2-0bf7-11ed-9481-000c291151eb'),
(65, 'San Salvador', 'El Salvador', 'USD', 'Dollar', '$', '', 'el_salvador.gif', '+503', 'SV', 'Deactive', '', 'KMs', 'd4289cd3-0bf7-11ed-9481-000c291151eb'),
(66, 'Malabo', 'Equatorial Guinea', 'XAF', 'Franc', '$', '', 'equatorial_guinea.gif', '+240', 'GQ', 'Deactive', '', 'KMs', 'd4289d04-0bf7-11ed-9481-000c291151eb'),
(67, 'Asmara', 'Eritrea', 'ERN', 'Nakfa', '$', '', '', '+291', 'ER', 'Deactive', '', 'KMs', 'd4289d36-0bf7-11ed-9481-000c291151eb'),
(68, 'Tallinn', 'Estonia', 'EEK', 'Kroon', '$', '', 'estonia.gif', '+372', 'EE', 'Deactive', '', 'KMs', 'd4289d66-0bf7-11ed-9481-000c291151eb'),
(69, 'Addis Ababa', 'Ethiopia', 'ETB', 'Birr', '$', '', 'ethiopia.gif', '+251', 'ET', 'Deactive', '', 'KMs', 'd4289d96-0bf7-11ed-9481-000c291151eb'),
(70, '', 'External Territories of Australia', '', '', '$', '', '', '+', 'XA', 'Deactive', '', 'KMs', 'd4289dc8-0bf7-11ed-9481-000c291151eb'),
(71, '', 'Falkland Islands', '', '', '$', '', '', '+', 'FK', 'Deactive', '', 'KMs', 'd4289df9-0bf7-11ed-9481-000c291151eb'),
(72, 'Torshavn', 'Faroe Islands', 'DKK', 'Krone', '$', '', '', '+298', 'FO', 'Deactive', '', 'KMs', 'd4289e2d-0bf7-11ed-9481-000c291151eb'),
(73, '', 'Fiji Islands', '', '', '$', '', '', '+', 'FJ', 'Deactive', '', 'KMs', 'd4289e5e-0bf7-11ed-9481-000c291151eb'),
(74, 'Helsinki', 'Finland', 'EUR', 'Euro', '$', '', 'finland.gif', '+358', 'FI', 'Deactive', '', 'KMs', 'd4289e8f-0bf7-11ed-9481-000c291151eb'),
(75, 'Paris', 'France', 'EUR', 'Euro', '$', '', 'france.gif', '+33', 'FR', 'Deactive', '', 'KMs', 'd4289ec1-0bf7-11ed-9481-000c291151eb'),
(76, 'Cayenne', 'French Guiana', 'EUR', 'Euro', '$', '', '', '+594', 'GF', 'Deactive', '', 'KMs', 'd4289ef2-0bf7-11ed-9481-000c291151eb'),
(77, 'Papeete', 'French Polynesia', 'XPF', 'Franc', '$', '', 'french_guiana.gif', '+689', 'PF', 'Deactive', '', 'KMs', 'd4289f24-0bf7-11ed-9481-000c291151eb'),
(78, '', 'French Southern Territories', '', '', '$', '', '', '+', 'TF', 'Deactive', '', 'KMs', 'd4289f55-0bf7-11ed-9481-000c291151eb'),
(79, 'Libreville', 'Gabon', 'XAF', 'Franc', '$', '', 'gabon.gif', '+241', 'GA', 'Deactive', '', 'KMs', 'd4289f86-0bf7-11ed-9481-000c291151eb'),
(80, '', 'Gambia The', '', '', '$', '', '', '+', 'GM', 'Deactive', '', 'KMs', 'd4289fb7-0bf7-11ed-9481-000c291151eb'),
(81, 'Tbilisi', 'Georgia', 'GEL', 'Lari', '$', '', 'georgia.gif', '+995', 'GE', 'Deactive', '', 'KMs', 'd4289fe8-0bf7-11ed-9481-000c291151eb'),
(82, 'Berlin', 'Germany', 'EUR', 'Euro', '$', '', 'germany.gif', '+49', 'DE', 'Deactive', '', 'KMs', 'd428a019-0bf7-11ed-9481-000c291151eb'),
(83, 'Accra', 'Ghana', 'GHC', 'Cedi', '$', '', 'ghana.gif', '+233', 'GH', 'Deactive', '', 'KMs', 'd428a04b-0bf7-11ed-9481-000c291151eb'),
(84, 'Gibraltar', 'Gibraltar', 'GIP', 'Pound', '$', '', 'gibraltar.gif', '+350', 'GI', 'Deactive', '', 'KMs', 'd428a07d-0bf7-11ed-9481-000c291151eb'),
(85, 'Athens', 'Greece', 'EUR', 'Euro', '$', '', 'greece.gif', '+30', 'GR', 'Deactive', '', 'KMs', 'd428a0ae-0bf7-11ed-9481-000c291151eb'),
(86, 'Nuuk (Godthab)', 'Greenland', 'DKK', 'Krone', '$', '', 'greenland.gif', '+299', 'GL', 'Deactive', '', 'KMs', 'd428a0de-0bf7-11ed-9481-000c291151eb'),
(87, 'Saint Georges', 'Grenada', 'XCD', 'Dollar', '$', '', 'grenada.gif', '-472', 'GD', 'Deactive', '', 'KMs', 'd428a10f-0bf7-11ed-9481-000c291151eb'),
(88, 'Basse-Terre', 'Guadeloupe', 'EUR', 'Euro', '$', '', 'guadeloupe.gif', '+590', 'GP', 'Deactive', '', 'KMs', 'd428a141-0bf7-11ed-9481-000c291151eb'),
(89, 'Hagatna', 'Guam', 'USD', 'Dollar', '$', '', 'guam.gif', '-670', 'GU', 'Deactive', '', 'KMs', 'd428a171-0bf7-11ed-9481-000c291151eb'),
(90, 'Guatemala', 'Guatemala', 'GTQ', 'Quetzal', '$', '', 'guatemala.gif', '+502', 'GT', 'Deactive', '', 'KMs', 'd428a1a3-0bf7-11ed-9481-000c291151eb'),
(91, '', 'Guernsey and Alderney', '', '', '$', '', '', '+', 'XU', 'Deactive', '', 'KMs', 'd428a1d7-0bf7-11ed-9481-000c291151eb'),
(92, 'Conakry', 'Guinea', 'GNF', 'Franc', '$', '', 'guinea.gif', '+224', 'GN', 'Deactive', '', 'KMs', 'd428a209-0bf7-11ed-9481-000c291151eb'),
(93, 'Bissau', 'Guinea-Bissau', 'XOF', 'Franc', '$', '', '', '+245', 'GW', 'Deactive', '', 'KMs', 'd428a23a-0bf7-11ed-9481-000c291151eb'),
(94, 'Georgetown', 'Guyana', 'GYD', 'Dollar', '$', '', 'guyana.gif', '+592', 'GY', 'Active', '', 'KMs', 'd428a26c-0bf7-11ed-9481-000c291151eb'),
(95, 'Port-au-Prince', 'Haiti', 'HTG', 'Gourde', '$', '', 'haiti.gif', '+509', 'HT', 'Deactive', '', 'KMs', 'd428a363-0bf7-11ed-9481-000c291151eb'),
(96, '', 'Heard and McDonald Islands', '', '', '$', '', '', '+', 'HM', 'Deactive', '', 'KMs', 'd428a397-0bf7-11ed-9481-000c291151eb'),
(97, 'Tegucigalpa', 'Honduras', 'HNL', 'Lempira', '$', '', 'honduras.gif', '+504', 'HN', 'Deactive', '', 'KMs', 'd428a40b-0bf7-11ed-9481-000c291151eb'),
(98, '', 'Hong Kong S.A.R.', '', '', '$', '', '', '+', 'HK', 'Deactive', '', 'KMs', 'd428a652-0bf7-11ed-9481-000c291151eb'),
(99, 'Budapest', 'Hungary', 'HUF', 'Forint', '$', '', 'hungary.gif', '+36', 'HU', 'Deactive', '', 'KMs', 'd428a698-0bf7-11ed-9481-000c291151eb'),
(100, 'Reykjavik', 'Iceland', 'ISK', 'Krona', '$', '', 'iceland.gif', '+354', 'IS', 'Deactive', '', 'KMs', 'd428a6cd-0bf7-11ed-9481-000c291151eb'),
(101, 'New Delhi', 'India', 'INR', 'Rupee', '₹', '', 'india.gif', '+91', 'IN', 'Active', '', 'KMs', 'd428a700-0bf7-11ed-9481-000c291151eb'),
(102, 'Jakarta', 'Indonesia', 'IDR', 'Rupiah', '$', '', 'indonesia.gif', '+62', 'ID', 'Deactive', '', 'KMs', 'd428a735-0bf7-11ed-9481-000c291151eb'),
(103, 'Tehran', 'Iran', 'IRR', 'Rial', '$', '', 'iran.gif', '+98', 'IR', 'Deactive', '', 'KMs', 'd428a769-0bf7-11ed-9481-000c291151eb'),
(104, 'Baghdad', 'Iraq', 'IQD', 'Dinar', 'ع.د', '', 'iraq.gif', '+964', 'IQ', 'Deactive', '', 'KMs', 'd428a79d-0bf7-11ed-9481-000c291151eb'),
(105, 'Dublin', 'Ireland', 'EUR', 'Euro', '$', '', 'ireland.gif', '+353', 'IE', 'Deactive', '', 'KMs', 'd428a7d0-0bf7-11ed-9481-000c291151eb'),
(106, 'Jerusalem', 'Israel', 'ILS', 'Shekel', '$', '', 'israel.gif', '+972', 'IL', 'Deactive', '', 'KMs', 'd428a803-0bf7-11ed-9481-000c291151eb'),
(107, 'Rome', 'Italy', 'EUR', 'Euro', '$', '', 'italy.gif', '+39', 'IT', 'Deactive', '', 'KMs', 'd428a834-0bf7-11ed-9481-000c291151eb'),
(108, 'Kingston', 'Jamaica', 'JMD', 'Dollar', '$', '', 'jamaica.gif', '-875', 'JM', 'Deactive', '', 'KMs', 'd428a868-0bf7-11ed-9481-000c291151eb'),
(109, 'Tokyo', 'Japan', 'JPY', 'Yen', '$', '', 'japan.gif', '+81', 'JP', 'Deactive', '', 'KMs', 'd428a899-0bf7-11ed-9481-000c291151eb'),
(110, 'Saint Helier', 'Jersey', 'JEP', 'Pound', '$', '', '', '+44', 'XJ', 'Deactive', '', 'KMs', 'd428a8cc-0bf7-11ed-9481-000c291151eb'),
(111, 'Amman', 'Jordan', 'JOD', 'Dinar', '$', '', 'jordan.gif', '+962', 'JO', 'Deactive', '', 'KMs', 'd428a8fd-0bf7-11ed-9481-000c291151eb'),
(112, 'Astana', 'Kazakhstan', 'KZT', 'Tenge', '$', '', 'kazakhstan.gif', '+7', 'KZ', 'Deactive', '', 'KMs', 'd428a92f-0bf7-11ed-9481-000c291151eb'),
(113, 'Nairobi', 'Kenya', 'KES', 'Shilling', '$', '', 'kenya.gif', '+254', 'KE', 'Deactive', '', 'KMs', 'd428a961-0bf7-11ed-9481-000c291151eb'),
(114, 'Tarawa', 'Kiribati', 'AUD', 'Dollar', '$', '', '', '+686', 'KI', 'Deactive', '', 'KMs', 'd428a993-0bf7-11ed-9481-000c291151eb'),
(115, '', 'Korea North', '', '', '$', '', '', '+', 'KP', 'Deactive', '', 'KMs', 'd428a9c7-0bf7-11ed-9481-000c291151eb'),
(116, '', 'Korea South', '', '', '$', '', '', '+', 'KR', 'Deactive', '', 'KMs', 'd428a9fb-0bf7-11ed-9481-000c291151eb'),
(117, 'Kuwait', 'Kuwait', 'KWD', 'Dinar', '$', '', 'kuwait.gif', '+965', 'KW', 'Deactive', '', 'KMs', 'd428aa2e-0bf7-11ed-9481-000c291151eb'),
(118, 'Bishkek', 'Kyrgyzstan', 'KGS', 'Som', '$', '', '', '+996', 'KG', 'Deactive', '', 'KMs', 'd428aa60-0bf7-11ed-9481-000c291151eb'),
(119, 'Vientiane', 'Laos', 'LAK', 'Kip', '$', '', 'laos.gif', '+856', 'LA', 'Deactive', '', 'KMs', 'd428aa94-0bf7-11ed-9481-000c291151eb'),
(120, 'Riga', 'Latvia', 'LVL', 'Lat', '$', '', 'latvia.gif', '+371', 'LV', 'Deactive', '', 'KMs', 'd428b0e6-0bf7-11ed-9481-000c291151eb'),
(121, 'Beirut', 'Lebanon', 'LBP', 'Pound', '$', '', 'lebanon.gif', '+961', 'LB', 'Deactive', '', 'KMs', 'd428b13a-0bf7-11ed-9481-000c291151eb'),
(122, 'Maseru', 'Lesotho', 'LSL', 'Loti', '$', '', 'lesotho.gif', '+266', 'LS', 'Deactive', '', 'KMs', 'd428b16f-0bf7-11ed-9481-000c291151eb'),
(123, 'Monrovia', 'Liberia', 'LRD', 'Dollar', '$', '', 'liberia.gif', '+231', 'LR', 'Deactive', '', 'KMs', 'd428b1b0-0bf7-11ed-9481-000c291151eb'),
(124, 'Tripoli', 'Libya', 'LYD', 'Dinar', '$', '', 'libya.gif', '+218', 'LY', 'Deactive', '', 'KMs', 'd428b1ea-0bf7-11ed-9481-000c291151eb'),
(125, 'Vaduz', 'Liechtenstein', 'CHF', 'Franc', '$', '', '', '+423', 'LI', 'Deactive', '', 'KMs', 'd428b221-0bf7-11ed-9481-000c291151eb'),
(126, 'Vilnius', 'Lithuania', 'LTL', 'Litas', '$', '', 'lithuania.gif', '+370', 'LT', 'Deactive', '', 'KMs', 'd428b25a-0bf7-11ed-9481-000c291151eb'),
(127, 'Luxembourg', 'Luxembourg', 'EUR', 'Euro', '$', '', 'luxembourg.gif', '+352', 'LU', 'Deactive', '', 'KMs', 'd428b292-0bf7-11ed-9481-000c291151eb'),
(128, '', 'Macau S.A.R.', '', '', '$', '', '', '+', 'MO', 'Deactive', '', 'KMs', 'd428b2ca-0bf7-11ed-9481-000c291151eb'),
(129, 'Skopje', 'Macedonia', 'MKD', 'Denar', '$', '', 'macedonia.gif', '+389', 'MK', 'Deactive', '', 'KMs', 'd428b303-0bf7-11ed-9481-000c291151eb'),
(130, 'Antananarivo', 'Madagascar', 'MGA', 'Ariary', '$', '', 'madagascar.gif', '+261', 'MG', 'Deactive', '', 'KMs', 'd428b33c-0bf7-11ed-9481-000c291151eb'),
(131, 'Lilongwe', 'Malawi', 'MWK', 'Kwacha', '$', '', 'malawi.gif', '+265', 'MW', 'Deactive', '', 'KMs', 'd428b374-0bf7-11ed-9481-000c291151eb'),
(132, 'Kuala Lumpur (legislative/judical) and Putrajaya (administrative)', 'Malaysia', 'MYR', 'Ringgit', '$', '', 'malaysia.gif', '+60', 'MY', 'Deactive', '', 'KMs', 'd428b3ad-0bf7-11ed-9481-000c291151eb'),
(133, 'Male', 'Maldives', 'MVR', 'Rufiyaa', '$', '', '', '+960', 'MV', 'Deactive', '', 'KMs', 'd428b3e9-0bf7-11ed-9481-000c291151eb'),
(134, 'Bamako', 'Mali', 'XOF', 'Franc', '$', '', 'mali.gif', '+223', 'ML', 'Deactive', '', 'KMs', 'd428b421-0bf7-11ed-9481-000c291151eb'),
(135, 'Valletta', 'Malta', 'MTL', 'Lira', '$', '', 'malta.gif', '+356', 'MT', 'Deactive', '', 'KMs', 'd428b458-0bf7-11ed-9481-000c291151eb'),
(136, '', 'Man (Isle of)', '', '', '$', '', '', '+', 'XM', 'Deactive', '', 'KMs', 'd428b490-0bf7-11ed-9481-000c291151eb'),
(137, 'Majuro', 'Marshall Islands', 'USD', 'Dollar', '$', '', '', '+692', 'MH', 'Deactive', '', 'KMs', 'd428b6e6-0bf7-11ed-9481-000c291151eb'),
(138, 'Fort-de-France', 'Martinique', 'EUR', 'Euro', '$', '', 'martinique.gif', '+596', 'MQ', 'Deactive', '', 'KMs', 'd428b721-0bf7-11ed-9481-000c291151eb'),
(139, 'Nouakchott', 'Mauritania', 'MRO', 'Ouguiya', '$', '', 'mauritania.gif', '+222', 'MR', 'Deactive', '', 'KMs', 'd428b757-0bf7-11ed-9481-000c291151eb'),
(140, 'Port Louis', 'Mauritius', 'MUR', 'Rupee', '$', '', 'mauritius.gif', '+230', 'MU', 'Deactive', '', 'KMs', 'd428b78e-0bf7-11ed-9481-000c291151eb'),
(141, 'Mamoudzou', 'Mayotte', 'EUR', 'Euro', '$', '', 'mayotte.gif', '+262', 'YT', 'Deactive', '', 'KMs', 'd428b7c5-0bf7-11ed-9481-000c291151eb'),
(142, 'Mexico', 'Mexico', 'MXN', 'Peso', '$', '', 'mexico.gif', '+52', 'MX', 'Deactive', '', 'KMs', 'd428b7fb-0bf7-11ed-9481-000c291151eb'),
(143, 'Palikir', 'Micronesia', 'USD', 'Dollar', '$', '', 'micronesia.gif', '+691', 'FM', 'Deactive', '', 'KMs', 'd428b833-0bf7-11ed-9481-000c291151eb'),
(144, 'Chisinau', 'Moldova', 'MDL', 'Leu', '$', '', '', '+373', 'MD', 'Deactive', '', 'KMs', 'd428b86b-0bf7-11ed-9481-000c291151eb'),
(145, 'Monaco', 'Monaco', 'EUR', 'Euro', '$', '', '', '+377', 'MC', 'Deactive', '', 'KMs', 'd428b8a4-0bf7-11ed-9481-000c291151eb'),
(146, 'Ulaanbaatar', 'Mongolia', 'MNT', 'Tugrik', '$', '', 'mongolia.gif', '+976', 'MN', 'Deactive', '', 'KMs', 'd428b8dc-0bf7-11ed-9481-000c291151eb'),
(147, 'Plymouth', 'Montserrat', 'XCD', 'Dollar', '$', '', '', '-663', 'MS', 'Deactive', '', 'KMs', 'd428b913-0bf7-11ed-9481-000c291151eb'),
(148, 'Rabat', 'Morocco', 'MAD', 'Dirham', '$', '', 'morocco.gif', '+212', 'MA', 'Deactive', '', 'KMs', 'd428b94c-0bf7-11ed-9481-000c291151eb'),
(149, 'Maputo', 'Mozambique', 'MZM', 'Meticail', '$', '', 'mozambique.gif', '+258', 'MZ', 'Deactive', '', 'KMs', 'd428b983-0bf7-11ed-9481-000c291151eb'),
(150, '', 'Myanmar', '', '', '$', '', '', '+', 'MM', 'Deactive', '', 'KMs', 'd428b9bc-0bf7-11ed-9481-000c291151eb'),
(151, 'Windhoek', 'Namibia', 'NAD', 'Dollar', '$', '', 'namibia.gif', '+264', 'NA', 'Deactive', '', 'KMs', 'd428b9f3-0bf7-11ed-9481-000c291151eb'),
(152, 'Yaren', 'Nauru', 'AUD', 'Dollar', '$', '', '', '+674', 'NR', 'Deactive', '', 'KMs', 'd428ba2c-0bf7-11ed-9481-000c291151eb'),
(153, 'Kathmandu', 'Nepal', 'NPR', 'Rupee', '$', '', 'nepal.gif', '+977', 'NP', 'Deactive', '', 'KMs', 'd428ba64-0bf7-11ed-9481-000c291151eb'),
(154, 'Willemstad', 'Netherlands Antilles', 'ANG', 'Guilder', '$', '', 'netherlands.gif', '+599', 'AN', 'Deactive', '', 'KMs', 'd428ba9c-0bf7-11ed-9481-000c291151eb'),
(155, '', 'Netherlands The', '', '', '$', '', '', '+', 'NL', 'Deactive', '', 'KMs', 'd428bad6-0bf7-11ed-9481-000c291151eb'),
(156, 'Noumea', 'New Caledonia', 'XPF', 'Franc', '$', '', 'new_caledonia.gif', '+687', 'NC', 'Deactive', '', 'KMs', 'd428bb12-0bf7-11ed-9481-000c291151eb'),
(157, 'Wellington', 'New Zealand', 'NZD', 'Dollar', '$', '', 'new_zealand.gif', '+64', 'NZ', 'Deactive', '', 'KMs', 'd428bb4b-0bf7-11ed-9481-000c291151eb'),
(158, 'Managua', 'Nicaragua', 'NIO', 'Cordoba', '$', '', 'nicaragua.gif', '+505', 'NI', 'Deactive', '', 'KMs', 'd428bb85-0bf7-11ed-9481-000c291151eb'),
(159, 'Niamey', 'Niger', 'XOF', 'Franc', '$', '', 'niger.gif', '+227', 'NE', 'Deactive', '', 'KMs', 'd428bbbd-0bf7-11ed-9481-000c291151eb'),
(160, 'Abuja', 'Nigeria', 'NGN', 'Naira', '$', '', 'nigeria.gif', '+234', 'NG', 'Deactive', '', 'KMs', 'd428bbf4-0bf7-11ed-9481-000c291151eb'),
(161, 'Alofi', 'Niue', 'NZD', 'Dollar', '$', '', '', '+683', 'NU', 'Deactive', '', 'KMs', 'd428bc2c-0bf7-11ed-9481-000c291151eb'),
(162, 'Kingston', 'Norfolk Island', 'AUD', 'Dollar', '$', '', '', '+672', 'NF', 'Deactive', '', 'KMs', 'd428bc64-0bf7-11ed-9481-000c291151eb'),
(163, 'Saipan', 'Northern Mariana Islands', 'USD', 'Dollar', '$', '', 'northern_mariana_islands.gif', '-669', 'MP', 'Deactive', '', 'KMs', 'd428be7b-0bf7-11ed-9481-000c291151eb'),
(164, 'Oslo', 'Norway', 'NOK', 'Krone', '$', '', 'norway.gif', '+47', 'NO', 'Deactive', '', 'KMs', 'd428beb5-0bf7-11ed-9481-000c291151eb'),
(165, 'Muscat', 'Oman', 'OMR', 'Rial', '$', '', 'oman.gif', '+968', 'OM', 'Deactive', '', 'KMs', 'd428bee9-0bf7-11ed-9481-000c291151eb'),
(166, 'Islamabad', 'Pakistan', 'PKR', 'Rupee', '$', '', 'pakistan.gif', '+92', 'PK', 'Deactive', '', 'KMs', 'd428bf21-0bf7-11ed-9481-000c291151eb'),
(167, 'Melekeok', 'Palau', 'USD', 'Dollar', '$', '', '', '+680', 'PW', 'Deactive', '', 'KMs', 'd428bf5a-0bf7-11ed-9481-000c291151eb'),
(168, '', 'Palestinian Territory Occupied', '', '', '$', '', '', '+', 'PS', 'Deactive', '', 'KMs', 'd428bf92-0bf7-11ed-9481-000c291151eb'),
(169, 'Panama', 'Panama', 'PAB', 'Balboa', '$', '', 'panama.gif', '+507', 'PA', 'Deactive', '', 'KMs', 'd428bfce-0bf7-11ed-9481-000c291151eb'),
(170, 'Port Moresby', 'Papua new Guinea', 'PGK', 'Kina', '$', '', 'papua_new_guinea.gif', '+675', 'PG', 'Deactive', '', 'KMs', 'd428c006-0bf7-11ed-9481-000c291151eb'),
(171, 'Asuncion', 'Paraguay', 'PYG', 'Guarani', '$', '', 'paraguay.gif', '+595', 'PY', 'Deactive', '', 'KMs', 'd428c040-0bf7-11ed-9481-000c291151eb'),
(172, 'Lima', 'Peru', 'PEN', 'Sol', '$', '', 'peru.gif', '+51', 'PE', 'Active', '', 'KMs', 'd428c078-0bf7-11ed-9481-000c291151eb'),
(173, 'Manila', 'Philippines', 'PHP', 'Peso', '$', '', 'philippines.gif', '+63', 'PH', 'Deactive', '', 'KMs', 'd428c0b2-0bf7-11ed-9481-000c291151eb'),
(174, '', 'Pitcairn Island', '', '', '$', '', '', '+', 'PN', 'Deactive', '', 'KMs', 'd428c111-0bf7-11ed-9481-000c291151eb'),
(175, 'Warsaw', 'Poland', 'PLN', 'Zloty', '$', '', 'poland.gif', '+48', 'PL', 'Deactive', '', 'KMs', 'd428c14b-0bf7-11ed-9481-000c291151eb'),
(176, 'Lisbon', 'Portugal', 'EUR', 'Euro', '$', '', 'portugal.gif', '+351', 'PT', 'Deactive', '', 'KMs', 'd428c183-0bf7-11ed-9481-000c291151eb'),
(177, 'San Juan', 'Puerto Rico', 'USD', 'Dollar', '$', '', 'puerto_rico.gif', '+1-787 and 1-939', 'PR', 'Deactive', '', 'KMs', 'd428c1ba-0bf7-11ed-9481-000c291151eb'),
(178, 'Doha', 'Qatar', 'QAR', 'Rial', '$', '', 'qatar.gif', '+974', 'QA', 'Deactive', '', 'KMs', 'd428c1f5-0bf7-11ed-9481-000c291151eb'),
(179, 'Saint-Denis', 'Reunion', 'EUR', 'Euro', '$', '', 'reunion.gif', '+262', 'RE', 'Deactive', '', 'KMs', 'd428c22c-0bf7-11ed-9481-000c291151eb'),
(180, 'Bucharest', 'Romania', 'RON', 'Leu', '$', '', 'romania.gif', '+40', 'RO', 'Deactive', '', 'KMs', 'd428c453-0bf7-11ed-9481-000c291151eb'),
(181, 'Moscow', 'Russia', 'RUB', 'Ruble', '$', '', 'russia.gif', '+7', 'RU', 'Deactive', '', 'KMs', 'd428c48c-0bf7-11ed-9481-000c291151eb'),
(182, 'Kigali', 'Rwanda', 'RWF', 'Franc', '$', '', 'rwanda.gif', '+250', 'RW', 'Deactive', '', 'KMs', 'd428c4c1-0bf7-11ed-9481-000c291151eb'),
(183, 'Jamestown', 'Saint Helena', 'SHP', 'Pound', '$', '', '', '+290', 'SH', 'Deactive', '', 'KMs', 'd428c4f8-0bf7-11ed-9481-000c291151eb'),
(184, 'Basseterre', 'Saint Kitts And Nevis', 'XCD', 'Dollar', '$', '', '', '-868', 'KN', 'Deactive', '', 'KMs', 'd428c530-0bf7-11ed-9481-000c291151eb'),
(185, 'Castries', 'Saint Lucia', 'XCD', 'Dollar', '$', '', '', '-757', 'LC', 'Deactive', '', 'KMs', 'd428c568-0bf7-11ed-9481-000c291151eb'),
(186, 'Saint-Pierre', 'Saint Pierre and Miquelon', 'EUR', 'Euro', '$', '', '', '+508', 'PM', 'Deactive', '', 'KMs', 'd428c5a1-0bf7-11ed-9481-000c291151eb'),
(187, 'Kingstown', 'Saint Vincent And The Grenadines', 'XCD', 'Dollar', '$', '', '', '-783', 'VC', 'Deactive', '', 'KMs', 'd428c5d9-0bf7-11ed-9481-000c291151eb'),
(188, 'Apia', 'Samoa', 'WST', 'Tala', '$', '', 'samoa.gif', '+685', 'WS', 'Deactive', '', 'KMs', 'd428c613-0bf7-11ed-9481-000c291151eb'),
(189, 'San Marino', 'San Marino', 'EUR', 'Euro', '$', '', '', '+378', 'SM', 'Deactive', '', 'KMs', 'd428c64b-0bf7-11ed-9481-000c291151eb'),
(190, 'Sao Tome', 'Sao Tome and Principe', 'STD', 'Dobra', '$', '', '', '+239', 'ST', 'Deactive', '', 'KMs', 'd428c684-0bf7-11ed-9481-000c291151eb'),
(191, 'Riyadh', 'Saudi Arabia', 'SAR', 'Rial', '$', '', 'saudi_arabia.gif', '+966', 'SA', 'Deactive', '', 'KMs', 'd428c6bb-0bf7-11ed-9481-000c291151eb'),
(192, 'Dakar', 'Senegal', 'XOF', 'Franc', '$', '', 'senegal.gif', '+221', 'SN', 'Deactive', '', 'KMs', 'd428c8e5-0bf7-11ed-9481-000c291151eb'),
(193, 'Belgrade', 'Serbia', 'RSD', 'Dinar', '$', '', '', '+381', 'RS', 'Deactive', '', 'KMs', 'd428c91e-0bf7-11ed-9481-000c291151eb'),
(194, 'Victoria', 'Seychelles', 'SCR', 'Rupee', '$', '', 'seychelles.gif', '+248', 'SC', 'Deactive', '', 'KMs', 'd428c955-0bf7-11ed-9481-000c291151eb'),
(195, 'Freetown', 'Sierra Leone', 'SLL', 'Leone', '$', '', 'sierra leone.gif', '+232', 'SL', 'Deactive', '', 'KMs', 'd428c98f-0bf7-11ed-9481-000c291151eb'),
(196, 'Singapore', 'Singapore', 'SGD', 'Dollar', '$', '', 'singapore.gif', '+65', 'SG', 'Deactive', '', 'KMs', 'd428c9c7-0bf7-11ed-9481-000c291151eb'),
(197, 'Bratislava', 'Slovakia', 'SKK', 'Koruna', '$', '', 'slovakia.gif', '+421', 'SK', 'Deactive', '', 'KMs', 'd428c9fe-0bf7-11ed-9481-000c291151eb'),
(198, 'Ljubljana', 'Slovenia', 'EUR', 'Euro', '$', '', 'slovenia.gif', '+386', 'SI', 'Deactive', '', 'KMs', 'd428ca35-0bf7-11ed-9481-000c291151eb'),
(199, '', 'Smaller Territories of the UK', '', '', '$', '', '', '+', 'XG', 'Deactive', '', 'KMs', 'd428ca6c-0bf7-11ed-9481-000c291151eb'),
(200, 'Honiara', 'Solomon Islands', 'SBD', 'Dollar', '$', '', 'solomon_islands.gif', '+677', 'SB', 'Deactive', '', 'KMs', 'd428cc4e-0bf7-11ed-9481-000c291151eb'),
(201, 'Mogadishu', 'Somalia', 'SOS', 'Shilling', '$', '', 'somalia.gif', '+252', 'SO', 'Deactive', '', 'KMs', 'd428cc85-0bf7-11ed-9481-000c291151eb'),
(202, 'Pretoria (administrative), Cape Town (legislative), and Bloemfontein (judical)', 'South Africa', 'ZAR', 'Rand', '$', '', 'south_africa.gif', '+27', 'ZA', 'Deactive', '', 'KMs', 'd428ccf8-0bf7-11ed-9481-000c291151eb'),
(203, '', 'South Georgia', '', '', '$', '', '', '+', 'GS', 'Deactive', '', 'KMs', 'd428cd37-0bf7-11ed-9481-000c291151eb'),
(204, '', 'South Sudan', '', '', '$', '', '', '+', 'SS', 'Deactive', '', 'KMs', 'd428cd6c-0bf7-11ed-9481-000c291151eb'),
(205, 'Madrid', 'Spain', 'EUR', 'Euro', '$', '', 'spain.gif', '+34', 'ES', 'Deactive', '', 'KMs', 'd428cf34-0bf7-11ed-9481-000c291151eb'),
(206, 'Colombo (administrative/judical) and Sri Jayewardenepura Kotte (legislative)', 'Sri Lanka', 'LKR', 'Rupee', '$', '', 'sri lanka.gif', '+94', 'LK', 'Deactive', '', 'KMs', 'd428cf94-0bf7-11ed-9481-000c291151eb'),
(207, 'Khartoum', 'Sudan', 'SDD', 'Dinar', '$', '', 'sudan.gif', '+249', 'SD', 'Deactive', '', 'KMs', 'd428cfcb-0bf7-11ed-9481-000c291151eb'),
(208, 'Paramaribo', 'Suriname', 'SRD', 'Dollar', '$', '', 'suriname.gif', '+597', 'SR', 'Deactive', '', 'KMs', 'd428d019-0bf7-11ed-9481-000c291151eb'),
(209, '', 'Svalbard And Jan Mayen Islands', '', '', '$', '', '', '+', 'SJ', 'Deactive', '', 'KMs', 'd428d1d9-0bf7-11ed-9481-000c291151eb'),
(210, 'Mbabane (administrative) and Lobamba (legislative)', 'Swaziland', 'SZL', 'Lilangeni', '$', '', 'swaziland.gif', '+268', 'SZ', 'Deactive', '', 'KMs', 'd428d22e-0bf7-11ed-9481-000c291151eb'),
(211, 'Stockholm', 'Sweden', 'SEK', 'Kronoa', '$', '', 'sweden.gif', '+46', 'SE', 'Deactive', '', 'KMs', 'd428d284-0bf7-11ed-9481-000c291151eb'),
(212, 'Bern', 'Switzerland', 'CHF', 'Franc', '$', '', 'switzerland.gif', '+41', 'CH', 'Deactive', '', 'KMs', 'd428d46b-0bf7-11ed-9481-000c291151eb'),
(213, 'Damascus', 'Syria', 'SYP', 'Pound', '$', '', 'syria.gif', '+963', 'SY', 'Deactive', '', 'KMs', 'd428d4bd-0bf7-11ed-9481-000c291151eb'),
(214, '', 'Taiwan', '', '', '$', '', 'taiwan.gif', '+', 'TW', 'Deactive', '', 'KMs', 'd428d67f-0bf7-11ed-9481-000c291151eb'),
(215, 'Dushanbe', 'Tajikistan', 'TJS', 'Somoni', '$', '', '', '+992', 'TJ', 'Deactive', '', 'KMs', 'd428d6d3-0bf7-11ed-9481-000c291151eb'),
(216, 'Dar es Salaam (administrative/judical) and Dodoma (legislative)', 'Tanzania', 'TZS', 'Shilling', '$', '', 'tanzania.gif', '+255', 'TZ', 'Deactive', '', 'KMs', 'd428d8b4-0bf7-11ed-9481-000c291151eb'),
(217, 'Bangkok', 'Thailand', 'THB', 'Baht', '$', '', 'thailand.gif', '+66', 'TH', 'Deactive', '', 'KMs', 'd428db25-0bf7-11ed-9481-000c291151eb'),
(218, 'Lome', 'Togo', 'XOF', 'Franc', '$', '', 'togo.gif', '+228', 'TG', 'Deactive', '', 'KMs', 'd428db86-0bf7-11ed-9481-000c291151eb'),
(219, '', 'Tokelau', 'NZD', 'Dollar', '$', '', '', '+690', 'TK', 'Deactive', '', 'KMs', 'd428dc01-0bf7-11ed-9481-000c291151eb'),
(220, 'Nuku alofa', 'Tonga', 'TOP', 'Paanga', '$', '', 'tonga.gif', '+676', 'TO', 'Deactive', '', 'KMs', 'd428dc5a-0bf7-11ed-9481-000c291151eb'),
(221, 'Port-of-Spain', 'Trinidad And Tobago', 'TTD', 'Dollar', '$', '', '', '-867', 'TT', 'Deactive', '', 'KMs', 'd428de23-0bf7-11ed-9481-000c291151eb'),
(222, 'Tunis', 'Tunisia', 'TND', 'Dinar', '$', '', 'tunisia.gif', '+216', 'TN', 'Deactive', '', 'KMs', 'd428dea0-0bf7-11ed-9481-000c291151eb'),
(223, 'Ankara', 'Turkey', 'TRY', 'Lira', '$', '', 'turkey.gif', '+90', 'TR', 'Deactive', '', 'KMs', 'd428defa-0bf7-11ed-9481-000c291151eb'),
(224, 'Ashgabat', 'Turkmenistan', 'TMM', 'Manat', '$', '', 'turkmenistan.gif', '+993', 'TM', 'Deactive', '', 'KMs', 'd428df52-0bf7-11ed-9481-000c291151eb'),
(225, 'Grand Turk', 'Turks And Caicos Islands', 'USD', 'Dollar', '$', '', '', '-648', 'TC', 'Deactive', '', 'KMs', 'd428dfab-0bf7-11ed-9481-000c291151eb'),
(226, 'Funafuti', 'Tuvalu', 'AUD', 'Dollar', '$', '', '', '+688', 'TV', 'Deactive', '', 'KMs', 'd428e003-0bf7-11ed-9481-000c291151eb'),
(227, 'Kampala', 'Uganda', 'UGX', 'Shilling', '$', '', 'uganda.gif', '+256', 'UG', 'Deactive', '', 'KMs', 'd428e05a-0bf7-11ed-9481-000c291151eb'),
(228, 'Kiev', 'Ukraine', 'UAH', 'Hryvnia', '$', '', 'ukraine.gif', '+380', 'UA', 'Deactive', '', 'KMs', 'd428e0b2-0bf7-11ed-9481-000c291151eb'),
(229, 'Abu Dhabi', 'United Arab Emirates', 'AED', 'Dirham', '$', '', '', '+971', 'AE', 'Deactive', '', 'KMs', 'd428e0ee-0bf7-11ed-9481-000c291151eb'),
(230, 'London', 'United Kingdom', 'GBP', 'Pound', '$', '', 'united_kingdom.gif', '+44', 'GB', 'Deactive', '', 'KMs', 'd428e129-0bf7-11ed-9481-000c291151eb'),
(231, 'Washington', 'United States', 'USD', 'Dollar', '$', '', '', '+1', 'US', 'Active', '', 'KMs', 'd428e161-0bf7-11ed-9481-000c291151eb'),
(232, '', 'United States Minor Outlying Islands', '', '', '$', '', '', '+', 'UM', 'Deactive', '', 'KMs', 'd428e19a-0bf7-11ed-9481-000c291151eb'),
(233, 'Montevideo', 'Uruguay', 'UYU', 'Peso', '$', '', 'uruguay.gif', '+598', 'UY', 'Deactive', '', 'KMs', 'd428e1d4-0bf7-11ed-9481-000c291151eb'),
(234, 'Tashkent', 'Uzbekistan', 'UZS', 'Som', '$', '', 'uzbekistan.gif', '+998', 'UZ', 'Deactive', '', 'KMs', 'd428e20d-0bf7-11ed-9481-000c291151eb'),
(235, 'Port-Vila', 'Vanuatu', 'VUV', 'Vatu', '$', '', 'vanuatu.gif', '+678', 'VU', 'Deactive', '', 'KMs', 'd428e244-0bf7-11ed-9481-000c291151eb'),
(236, '', 'Vatican City State (Holy See)', '', '', '$', '', '', '+', 'VA', 'Deactive', '', 'KMs', 'd428e27d-0bf7-11ed-9481-000c291151eb'),
(237, 'Caracas', 'Venezuela', 'VEB', 'Bolivar', '$', '', 'venezuela.gif', '+58', 'VE', 'Deactive', '', 'KMs', 'd428e2b5-0bf7-11ed-9481-000c291151eb'),
(238, 'Hanoi', 'Vietnam', 'VND', 'Dong', '$', '', '', '+84', 'VN', 'Deactive', '', 'KMs', 'd428e2ee-0bf7-11ed-9481-000c291151eb'),
(239, '', 'Virgin Islands (British)', '', '', '$', '', '', '+', 'VG', 'Deactive', '', 'KMs', 'd428e328-0bf7-11ed-9481-000c291151eb'),
(240, '', 'Virgin Islands (US)', '', '', '$', '', '', '+', 'VI', 'Deactive', '', 'KMs', 'd428e362-0bf7-11ed-9481-000c291151eb'),
(241, '', 'Wallis And Futuna Islands', '', '', '$', '', '', '+', 'WF', 'Deactive', '', 'KMs', 'd428e39d-0bf7-11ed-9481-000c291151eb'),
(242, '', 'Western Sahara', '', '', '$', '', '', '+', 'EH', 'Deactive', '', 'KMs', 'd428e3d5-0bf7-11ed-9481-000c291151eb'),
(243, 'Sanaa', 'Yemen', 'YER', 'Rial', '$', '', 'yemen.gif', '+967', 'YE', 'Deactive', '', 'KMs', 'd428e40e-0bf7-11ed-9481-000c291151eb'),
(244, '', 'Yugoslavia', '', '', '$', '', 'yugoslavia.gif', '+', 'YU', 'Deactive', '', 'KMs', 'd428e446-0bf7-11ed-9481-000c291151eb'),
(245, 'Lusaka', 'Zambia', 'ZMK', 'Kwacha', '$', '', 'zambia.gif', '+260', 'ZM', 'Deactive', '', 'KMs', 'd428e47e-0bf7-11ed-9481-000c291151eb'),
(246, 'Harare', 'Zimbabwe', 'ZWD', 'Dollar', '$', '', 'zimbabwe.gif', '+263', 'ZW', 'Deactive', '', 'KMs', 'd428e4b6-0bf7-11ed-9481-000c291151eb');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`country_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `country_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=247;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
